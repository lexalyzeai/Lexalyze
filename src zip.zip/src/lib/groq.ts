import { SYSTEM_PROMPT, REASONING_PROMPT, FOLLOWUP_PROMPT } from '@/lib/prompt'
import { AnalysisResult } from '@/types/analysis'

const GROQ_URL = 'https://api.groq.com/openai/v1/chat/completions'
const MODEL = 'llama-3.3-70b-versatile'

async function groqCall(
  messages: { role: string; content: string }[],
  jsonMode: boolean = false,
  maxTokens: number = 4000
): Promise<string> {
  const body: Record<string, unknown> = {
    model: MODEL,
    temperature: 0.1,
    top_p: 0.85,
    max_tokens: maxTokens,
    messages,
  }

  if (jsonMode) body.response_format = { type: 'json_object' }

  const response = await fetch(GROQ_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${process.env.GROQ_API_KEY}`
    },
    body: JSON.stringify(body)
  })

  if (!response.ok) {
    const errorBody = await response.json().catch(() => ({}))
    throw new Error(`Groq API error: ${response.status} — ${JSON.stringify(errorBody)}`)
  }

  const data = await response.json()
  const raw = data.choices?.[0]?.message?.content

  if (!raw) throw new Error('No response from Groq')

  return raw
}

function parseJson(raw: string): AnalysisResult {
  const cleaned = raw
    .replace(/^```json\s*/i, '')
    .replace(/^```\s*/i, '')
    .replace(/```$/i, '')
    .trim()

  try {
    const parsed = JSON.parse(cleaned) as Partial<AnalysisResult>

    const result: AnalysisResult = {
      documentTitle: parsed.documentTitle || 'Untitled Document',
      documentType: parsed.documentType || 'Legal Document',
      partyFavour: parsed.partyFavour || 'BALANCED',
      partyFavourReason: parsed.partyFavourReason || 'Could not determine party favour from document.',

      riskScore: parsed.riskScore ?? 5,
      riskScoreReason: parsed.riskScoreReason || 'Risk score estimated from detected clauses.',

      overallConfidence:
        parsed.overallConfidence ||
        ((parsed.redFlags?.length || 0) >= 3
          ? 'LOW'
          : (parsed.redFlags?.length || 0) >= 1
          ? 'MEDIUM'
          : 'HIGH'),
      overallConfidenceReason:
        parsed.overallConfidenceReason || 'Confidence estimated from detected clauses.',

      oneLineSummary: parsed.oneLineSummary || 'Document analysis completed.',
      fullSummary: parsed.fullSummary || 'No summary generated.',

      keyNumbers:
        parsed.keyNumbers && parsed.keyNumbers.length > 0
          ? parsed.keyNumbers
          : ['No important financial numbers detected.'],

      keyDeadlines:
        parsed.keyDeadlines && parsed.keyDeadlines.length > 0
          ? parsed.keyDeadlines
          : ['No important deadlines detected.'],

      redFlags:
        parsed.redFlags && parsed.redFlags.length > 0
          ? parsed.redFlags
          : [
              {
                title: 'Limited legal detail',
                severity: 'MEDIUM',
                explanation: 'The document contains limited legal clarification.',
                exactQuote: 'No exact quote found in document.',
                legalContext: 'Unable to determine applicable law from document content.',
                whatToDoAboutIt: 'Request a more detailed agreement from the other party.',
                confidence: 'MEDIUM',
                confidenceReason: 'Important clauses appear missing or unclear.',
              },
            ],

      positivePoints:
        parsed.positivePoints && parsed.positivePoints.length > 0
          ? parsed.positivePoints
          : [
              {
                title: 'Basic agreement structure present',
                explanation: 'The document contains identifiable agreement terms.',
                exactQuote: 'No exact quote found in document.',
                confidence: 'MEDIUM',
              },
            ],

      missingClauses:
        parsed.missingClauses && parsed.missingClauses.length > 0
          ? parsed.missingClauses
          : [
              {
                clause: 'Dispute Resolution Clause',
                whyItMatters: 'Without this, any dispute requires expensive court proceedings.',
                riskIfAbsent: 'HIGH',
                whatToAdd: 'Add an arbitration clause under the Arbitration and Conciliation Act, 1996.',
              },
            ],

      clauseAnalysis:
        parsed.clauseAnalysis && parsed.clauseAnalysis.length > 0
          ? parsed.clauseAnalysis
          : [
              {
                clauseTitle: 'General Terms',
                whatItSays: 'The document contains general agreement terms.',
                whatItMeans: 'Standard obligations apply to both parties.',
                isFair: true,
                consumerImpact: 'MEDIUM',
                redFlag: false,
              },
            ],

      actionItems:
        parsed.actionItems && parsed.actionItems.length > 0
          ? parsed.actionItems
          : [
              {
                priority: 'URGENT',
                action: 'Review the document carefully before signing.',
                reason: 'Several clauses require clarification.',
              },
            ],

      cannotDetermineList:
        parsed.cannotDetermineList && parsed.cannotDetermineList.length > 0
          ? parsed.cannotDetermineList
          : [
              'Dispute resolution process',
              'Termination consequences',
              'Maintenance responsibilities',
            ],

      negotiationTips:
        parsed.negotiationTips && parsed.negotiationTips.length > 0
          ? parsed.negotiationTips
          : [
              'Request mutual termination rights instead of one-sided clauses.',
              'Ask for a clearly defined security deposit refund timeline.',
              'Insist on a written inventory of any assets or property.',
            ],

      consumerRightsNote:
        parsed.consumerRightsNote ||
        'You have the right to negotiate any clause before signing. No contract term is final until you sign.',

      stampDutyNote:
        parsed.stampDutyNote ||
        'Verify whether this document requires stamping and/or registration under applicable state law.',

      lawyerGuidance:
        parsed.lawyerGuidance ||
        'Consult a qualified lawyer before signing. Bring this document and ask specifically about your exit rights and dispute resolution options.',
    }

    return result
  } catch {
    throw new Error('Failed to parse Groq response as JSON')
  }
}

export async function analyzeDocument(
  text: string,
  language: string = 'en'
): Promise<AnalysisResult> {

  // PASS 1 — Deep legal reasoning in plain text
  const legalReasoning = await groqCall(
    [
      {
        role: 'system',
        content: REASONING_PROMPT
      },
      {
        role: 'user',
        content: `Analyse this legal document thoroughly. Leave nothing out:\n\n${text}`
      }
    ],
    false,
    4000
  )

  // PASS 2 — Convert reasoning into structured JSON
  const rawJson = await groqCall(
    [
      {
        role: 'system',
        content: SYSTEM_PROMPT(language)
      },
      {
        role: 'user',
        content: `A senior advocate has completed a deep legal analysis of this document.

ADVOCATE'S ANALYSIS:
${legalReasoning}

ORIGINAL DOCUMENT:
${text}

Using the advocate's analysis and the original document, generate the complete JSON report.
Every field must be populated. Use the advocate's findings to make the analysis as thorough as possible.
Return ONLY valid JSON.`
      }
    ],
    true,
    8000
  )

  return parseJson(rawJson)
}

export async function followUpQuestion(
  question: string,
  documentText: string,
  analysisResult: AnalysisResult,
  language: 'en' | 'hi' = 'en'
): Promise<string> {

  return await groqCall(
    [
      {
        role: 'system',
        content: FOLLOWUP_PROMPT(language)
      },
      {
        role: 'user',
        content: `ORIGINAL DOCUMENT:
${documentText}

EXISTING ANALYSIS SUMMARY:
- Document Type: ${analysisResult.documentType}
- Risk Score: ${analysisResult.riskScore}/10
- Party Favour: ${analysisResult.partyFavour}
- Red Flags: ${analysisResult.redFlags?.map((r: { title: string }) => r.title).join(', ')}
- Missing Clauses: ${analysisResult.missingClauses?.map((m: { clause: string }) => m.clause).join(', ')}
- Full Summary: ${analysisResult.fullSummary}

USER QUESTION: ${question}`
      }
    ],
    false,
    1000
  )
}